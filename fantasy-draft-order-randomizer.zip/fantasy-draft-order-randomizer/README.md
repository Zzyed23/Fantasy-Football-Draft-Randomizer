# Fantasy Draft Order Randomizer

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Zzyed23/pen/019f16d9-dabe-779a-9cc8-e5adb03d3cd7](https://codepen.io/editor/Zzyed23/pen/019f16d9-dabe-779a-9cc8-e5adb03d3cd7).

